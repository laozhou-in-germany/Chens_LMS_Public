# My routines
## Miracle Morning routine
### I'm grateful for
+  

### Today's tasks for life goal
- [ ] 

### Positive self-affirmation
+ 

## Evening routine
### Three good things and my initiation
+  

### Improvement for tomorrow
+ 
