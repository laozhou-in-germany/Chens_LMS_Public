# Weekly plan
### Week reflection 
+  

### Next week tasks for life goal
- [ ]   