# My annual resolution 202x
## 💪 Lifelong learning
+ 

## 🚹 Individual
+ 

## 👪 Family
+ 

## 🍻 Friends and relatives
+ 

## 🛄 Job
+ 
