# Morgenroutinen
## Ich bin dankbar für  
+  

## Was würde heutigen Tag wundervoll machen? 
+  

## Positive Selbstbekräftigung
+  

# Abendroutinen
## Was habe ich heute gutes für jemanden getan
+  

## Was werde ich morgen besser machen
+  

## Tolle Dinge, die ich erlebt habe
+  

