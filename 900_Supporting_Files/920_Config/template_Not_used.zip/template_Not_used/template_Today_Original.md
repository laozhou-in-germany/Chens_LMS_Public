## Reflection of the previous day
Yesterday, I was grateful for:
In that moment I felt:
I expressed my gratitude for this moment by:  
## Goal of today
If nothing else, today I am going to:
I am going to fulfill this by 
+  
+  
+  

If I do this and only this, today will be a good day which will bring me closer to:  
## Principles
I am going to adhere to my goal by following these three principles:
1. 
2. 
3. 

## Morning Chores of today
I will start my morning by getting the following 5 annoying things done as quickly as possible:
1. 
2. 
3. 
4. 
5.  

## Morning Miracle of today
I recognise that it feels good having done the 5 things above. Now I allow myself to do the following 5 things for my personal growth:
1. 
2. 
3. 
4. 
5. 

## Freedom Feat of today
If I am done with everything I wanted to achieve today,I will spend my free time on:
+
+
+

## Notes of today
Over the entire day I have collected the following todo:, thought:, experience:,reflection:, idea:, feeling:, note:

