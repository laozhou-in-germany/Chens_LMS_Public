author::  
excerpt::   
fileClass:: literature-note   
mediaformat:: #book    
score::  
last-revision::  [[2022-01-01]]    
note-status:: #captured  
cover::  

