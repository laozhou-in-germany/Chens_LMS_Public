author:: 
excerpt::   
fileClass:: literature-note 
mediaformat:: #article   
score::  
last-revision:: [[2022-01-01]]  
note-status:: #captured  
cover::  
