#person/colleague

# L2_Person_template

## Personal Information

**Birthday:**   

**Company & Department:** 

**Live in:**  

**Hometown:**  

**Hobbies:**     

**Like:**    

**Dislike:**    

**Wish:**     

**Worry/Fear:**     

**Family:**     

## Events 

### 2022-01-23
dummy text






