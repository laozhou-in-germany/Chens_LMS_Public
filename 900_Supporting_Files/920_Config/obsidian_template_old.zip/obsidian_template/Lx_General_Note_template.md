excerpt::
fileClass:: evergreen-note   
score::  
last-revision::  [[2022-01-01]]
note-status:: 


