author
excerpt
fileClass:: {"type":"select","options":["Work-Journal","Literature-Note","Atomic-Note","Evergreen-Note","MOC"]}
category:: {"type":"select","options":["Book","Article","Video","Others"]}
tags
score:: {"type":"select","options":["x","xx","xxx","xxxx","xxxxx"]}
last-revision

