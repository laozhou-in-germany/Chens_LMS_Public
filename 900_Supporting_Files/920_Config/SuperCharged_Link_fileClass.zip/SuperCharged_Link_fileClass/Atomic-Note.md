
author
excerpt
fileClass:: {"type":"select","options":["Work-Journal","Literature-Note","Atomic-Note","Evergreen-Note","MOC"]}
category:: {"type":"select","options":["Aphorism","Concept","Information","Story","Opinion"]}
tags
score:: {"type":"select","options":["x","xx","xxx","xxxx","xxxxx"]}
revision:: {"type":"select","options":["x","xx","xxx","xxxx","xxxxx"]}
last_revision

