excerpt
fileClass:: {"type":"select","options":["Work-Journal","Literature-Note","Atomic-Note","Evergreen-Note","MOC"]}
category:: {"type":"select","options":["Me & Growth","Family","Careers","Interest"]}
tags
progress:: {"type":"select","options":["x","xx","xxx","xxxx","xxxxx"]}
score:: {"type":"select","options":["x","xx","xxx","xxxx","xxxxx"]}
revision:: {"type":"select","options":["x","xx","xxx","xxxx","xxxxx"]}
last_revision